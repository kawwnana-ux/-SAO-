#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
特許請求項SAO構造分析デモ - 環境自動セットアップスクリプト
=========================================================

このスクリプトは、SAO構造抽出デモ（app.py）を、あなたのPC上で動く
ローカルLLM（Ollama + qwen2.5:7b）を使って動かすために必要な環境を、
1ステップずつ確認しながら自動的にセットアップします。

使い方：
    python3 setup.py

  （Windowsで「python3」が使えない場合は「python setup.py」）

  ※ ダブルクリックで実行したい場合は、同じフォルダの
     setup_mac.command（Mac）／setup_windows.bat（Windows）を
     使ってください。

このスクリプトが順番に行うこと：
  ① Pythonのバージョン確認
  ② 必要なPythonパッケージのインストール（requirements.txt）
  ③ Ollamaがインストールされているか確認（無ければ案内して終了）
  ④ Ollamaサーバーが起動しているか確認（起動していなければ起動を試みる）
  ⑤ qwen2.5:7b モデルのダウンロード（ollama pull）
  ⑥ 最終確認、そして希望すればそのままアプリを起動

途中のステップで失敗しても、原因を直したあとにこのスクリプトを
もう一度実行すれば、すでに終わっているステップは自動的にスキップ
（または即座に確認完了）されるので、続きから再開できます。
"""

import platform
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
REQUIRED_MODEL = "qwen2.5:7b"
OLLAMA_HOST = "http://localhost:11434"
TOTAL_STEPS = 6

# 古いWindowsコンソールでは色付き文字が文字化けすることがあるため、
# うまく色が出せない環境では自動的に諦める。
_USE_COLOR = sys.stdout.isatty()


def _c(text, code):
    if not _USE_COLOR:
        return text
    return f"\033[{code}m{text}\033[0m"


def ok(msg):
    print(_c("✅ ", "32") + msg)


def warn(msg):
    print(_c("⚠️  ", "33") + msg)


def err(msg):
    print(_c("❌ ", "31") + msg)


def info(msg):
    print(_c("ℹ️  ", "36") + msg)


def step(n, title):
    print()
    print(_c(f"── ステップ {n}/{TOTAL_STEPS}：{title} ", "1;36") + _c("─" * 20, "36"))


def ask_yes_no(question, default=True):
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        try:
            ans = input(f"{question} {suffix}: ").strip().lower()
        except EOFError:
            return default
        if not ans:
            return default
        if ans in ("y", "yes"):
            return True
        if ans in ("n", "no"):
            return False
        print("y または n で答えてください。")


def run(cmd):
    """コマンドを実行し、標準出力・標準エラーをそのまま画面に流す。
    成功したら True、失敗（コマンドが無い／終了コードが非0）したら False。"""
    print(_c(f"$ {' '.join(cmd)}", "90"))
    try:
        result = subprocess.run(cmd)
        return result.returncode == 0
    except FileNotFoundError:
        return False


# ---------------------------------------------------------------------------
# ① Pythonバージョン確認
# ---------------------------------------------------------------------------
def step1_check_python():
    step(1, "Pythonバージョン確認")
    print(f"検出されたPython: {platform.python_version()} ({sys.executable})")
    if sys.version_info[:2] < (3, 9):
        err(
            "Python 3.9 以上が必要です。"
            "https://www.python.org/downloads/ から新しいバージョンを"
            "インストールしてから、もう一度このスクリプトを実行してください。"
        )
        return False
    ok("Pythonのバージョンは問題ありません。")
    return True


# ---------------------------------------------------------------------------
# ② 必要なPythonパッケージのインストール
# ---------------------------------------------------------------------------
def step2_install_python_packages():
    step(2, "必要なPythonパッケージのインストール")
    req_file = SCRIPT_DIR / "requirements.txt"
    if not req_file.exists():
        err(
            f"requirements.txt が見つかりません（{req_file}）。"
            "app.py・translate_sao.py・patent_pipeline.py・en_relation_rules.py・"
            "requirements.txt を、すべて同じフォルダに置いてから"
            "再実行してください。"
        )
        return False

    info("数分かかることがあります（GiNZA・spaCy関連は特に時間がかかります）。")
    success = run([sys.executable, "-m", "pip", "install", "-r", str(req_file)])
    if not success:
        err(
            "パッケージのインストールに失敗しました。上のエラーメッセージを"
            "確認してください。pipが古い場合は、次を試してから再実行して"
            "みてください：\n"
            f"    {sys.executable} -m pip install --upgrade pip"
        )
        return False
    ok("必要なパッケージをインストールしました。")
    return True


# ---------------------------------------------------------------------------
# ③ Ollamaのインストール確認
# ---------------------------------------------------------------------------
def _ollama_command_exists():
    return shutil.which("ollama") is not None


def step3_check_ollama_installed():
    step(3, "Ollamaのインストール確認")
    if _ollama_command_exists():
        ok("Ollamaがインストールされています。")
        return True

    err("Ollama（ローカルLLM実行環境）が見つかりません。qwen2.5:7bモデルを動かすために必要です。")
    print()
    print("以下から無料でインストールできます：")
    print("  👉 https://ollama.com/download")
    system = platform.system()
    if system == "Darwin":
        print("  Mac: ダウンロードした Ollama.dmg を開いてインストールしてください。")
    elif system == "Windows":
        print("  Windows: ダウンロードした OllamaSetup.exe を実行してください。")
    else:
        print("  Linux: 次のコマンドでもインストールできます：")
        print("    curl -fsSL https://ollama.com/install.sh | sh")
    print()
    print("インストールが終わったら、このスクリプトをもう一度実行してください")
    print("（②までのステップは自動的にスキップされ、すぐ続きから始まります）。")
    return False


# ---------------------------------------------------------------------------
# ④ Ollamaサーバーの起動確認
# ---------------------------------------------------------------------------
def _ollama_server_running():
    try:
        with urllib.request.urlopen(OLLAMA_HOST, timeout=2):
            return True
    except Exception:
        return False


def step4_ensure_ollama_running():
    step(4, "Ollamaサーバーの起動確認")
    if _ollama_server_running():
        ok("Ollamaサーバーは起動済みです。")
        return True

    warn("Ollamaサーバーが起動していません。起動を試みます…")
    try:
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        err("`ollama serve` を実行できませんでした。ステップ③を先に完了してください。")
        return False

    for _ in range(15):
        time.sleep(1)
        if _ollama_server_running():
            ok("Ollamaサーバーを起動しました。")
            return True

    err(
        "Ollamaサーバーの起動を確認できませんでした。"
        "別のターミナル（またはOllamaのデスクトップアプリ）で起動してから、"
        "もう一度このスクリプトを実行してみてください。"
    )
    return False


# ---------------------------------------------------------------------------
# ⑤ qwen2.5:7b モデルのダウンロード
# ---------------------------------------------------------------------------
def step5_pull_model():
    step(5, f"{REQUIRED_MODEL} モデルのダウンロード")
    info("初回は数GBのダウンロードが発生します（回線速度により数分〜数十分）。")
    info("2回目以降は、すでにダウンロード済みならすぐに完了します。")
    success = run(["ollama", "pull", REQUIRED_MODEL])
    if not success:
        err(
            f"{REQUIRED_MODEL} のダウンロードに失敗しました。"
            "ネットワーク接続を確認して、もう一度実行してください。"
        )
        return False
    ok(f"{REQUIRED_MODEL} の準備ができました。")
    return True


# ---------------------------------------------------------------------------
# ⑥ 最終確認 ＋ アプリの起動
# ---------------------------------------------------------------------------
def step6_verify_and_launch():
    step(6, "最終確認")
    checks = [
        ("streamlit", "Streamlit"),
        ("spacy", "spaCy"),
        ("ginza", "GiNZA"),
        ("pandas", "pandas"),
        ("ollama", "ollamaクライアント"),
    ]
    all_ok = True
    for module_name, display_name in checks:
        result = subprocess.run(
            [sys.executable, "-c", f"import {module_name}"],
            capture_output=True,
        )
        if result.returncode == 0:
            ok(f"{display_name} を読み込めました。")
        else:
            err(f"{display_name} の読み込みに失敗しました。")
            all_ok = False

    if not all_ok:
        err("一部のパッケージが正しくインストールされていません。上のエラーを確認してください。")
        return False

    print()
    ok("すべての準備が整いました！🎉")

    app_path = SCRIPT_DIR / "app.py"
    if not app_path.exists():
        warn(
            f"app.py が見つかりません（{app_path}）。"
            "app.pyをこのフォルダに置いてから、"
            f"`streamlit run {app_path}` を実行してください。"
        )
        return True

    print()
    if ask_yes_no("今すぐ `streamlit run app.py` でアプリを起動しますか？", default=True):
        print()
        info("ブラウザが自動で開きます。終了するには、このウィンドウで Ctrl+C を押してください。")
        subprocess.run([sys.executable, "-m", "streamlit", "run", str(app_path)])
    else:
        print()
        info("いつでも次のコマンドでアプリを起動できます：")
        print(f"    cd {SCRIPT_DIR}")
        print(f"    {sys.executable} -m streamlit run app.py")
    return True


def main():
    print(_c("=" * 62, "36"))
    print(_c("特許請求項SAO構造分析デモ － 環境自動セットアップ", "1"))
    print(_c("=" * 62, "36"))
    print(
        "SAO構造抽出デモを、あなたのPC上のローカルLLM"
        "（Ollama + qwen2.5:7b）で動かすための環境を、"
        "順番に確認・セットアップします。"
    )
    print("途中で失敗しても、直してから再実行すれば続きから再開できます。")

    steps = [
        step1_check_python,
        step2_install_python_packages,
        step3_check_ollama_installed,
        step4_ensure_ollama_running,
        step5_pull_model,
        step6_verify_and_launch,
    ]
    for fn in steps:
        if not fn():
            print()
            err("セットアップが途中で止まりました。上のメッセージを確認して、"
                "対処してから、もう一度このスクリプトを実行してください。")
            sys.exit(1)

    print()
    print(_c("=" * 62, "36"))
    ok("セットアップが完了しました。お疲れさまでした！")
    print(_c("=" * 62, "36"))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        warn("中断しました。")
        sys.exit(1)
