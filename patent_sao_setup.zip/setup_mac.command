#!/bin/bash
# ダブルクリックで実行できる、Mac用のセットアップ起動スクリプト。
# 同じフォルダの setup.py を呼び出すだけの薄いラッパーです。
cd "$(dirname "$0")"

if command -v python3 >/dev/null 2>&1; then
    python3 setup.py
else
    echo "❌ python3 が見つかりません。"
    echo "👉 https://www.python.org/downloads/ からPythonをインストールしてから、"
    echo "   もう一度このファイルをダブルクリックしてください。"
fi

echo ""
read -p "Enterキーを押すとこのウィンドウを閉じます..." _
