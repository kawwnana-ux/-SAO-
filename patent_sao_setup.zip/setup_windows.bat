@echo off
REM ダブルクリックで実行できる、Windows用のセットアップ起動スクリプト。
REM 同じフォルダの setup.py を呼び出すだけの薄いラッパーです。
cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel%==0 (
    python setup.py
    goto :end
)

where py >nul 2>nul
if %errorlevel%==0 (
    py setup.py
    goto :end
)

echo [失敗] Pythonが見つかりません。
echo https://www.python.org/downloads/ からPythonをインストールしてください。
echo インストール時に「Add python.exe to PATH」に必ずチェックを入れてください。

:end
echo.
pause
