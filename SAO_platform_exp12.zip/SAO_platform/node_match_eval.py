# -*- coding: utf-8 -*-
"""
node_match_eval.py
===================
主語どうし・目的語どうしを比べる評価（--eval-mode node）。

従来の緩い評価（evaluate_triples_lenient）は「ＡがＢをＲする」という文全体の
埋め込み類似度で一致を判定していたが、同じ請求項の構成要素をでたらめに
組み合わせた偽の関係でも97.8%がどれかの正解と類似度0.75以上になり、本文を
読まないでたらめな出力でもF1が67.1%になってしまうことが分かった。
そこで、意味的類似度は使いつつ、主語と目的語を別々に比べる。

一致の条件（1対1の対応付け）:
  ① 表記正規化で主語・目的語が一致し、関係も一致 → 一致（従来と同じ）
  ② 残りは、主語どうし・目的語どうしがそれぞれ次のどれかで対応し、かつ関係が一致:
       ・表記正規化で一致
       ・一方がもう一方を含む（例：「第１端」と「第１トランジスタの第１端」）。
         ただし短い方の番号（第１・Ａ等）が長い方にも含まれる場合のみ
       ・番号が同じで、埋め込みの類似度がθ（既定0.9）以上
     主語・目的語の対応の強さの小さい方が高い組から順に対応付ける。
  θ=0.9 の根拠：同じ請求項の別々の正解ノード同士（番号が同じ・包含関係なし）で
  類似度が0.9以上になるのは4.2%（0.75では27.2%）。
  関係の一致は従来の規則（表記正規化・漢字部分一致・同義語グループ）を使うが、
  同義語グループの「の」は関係全体が「の」の場合だけ認める（従来は「の」を含む
  あらゆる関係語が「有する」系と同義扱いになっていた）。
"""
import re

_KANJI_NUM = str.maketrans("一二三四五六七八九", "123456789")
_NUM_RE = re.compile(r"\d+|[a-zA-Z]")


def numbers(t):
    t = re.sub(r"第([一二三四五六七八九])", lambda m: "第" + m.group(1).translate(_KANJI_NUM), t)
    return tuple(_NUM_RE.findall(t))


def node_score(a, b, E, theta):
    if a == b:
        return 1.0
    short, long_ = (a, b) if len(a) <= len(b) else (b, a)
    if len(short) >= 2 and short in long_ and set(numbers(short)) <= set(numbers(long_)):
        return 0.9
    if numbers(a) != numbers(b):
        return 0.0
    s = float(E[a] @ E[b])
    return s if s >= theta else 0.0


def rel_match(pp, p_rel, g_rel):
    if p_rel == g_rel:
        return True
    pn = pp._normalize_relation_for_match(p_rel)
    gn = pp._normalize_relation_for_match(g_rel)
    if pn == gn or pn in gn or gn in pn:
        return True
    for group in pp.RELATION_SYNONYM_GROUPS:
        a_in = any((g in p_rel) if len(g) > 1 else (g == p_rel) for g in group)
        b_in = any((g in g_rel) if len(g) > 1 else (g == g_rel) for g in group)
        if a_in and b_in:
            return True
    return False


def evaluate_triples_node(pp, predicted, gold, theta=0.9):
    n = pp._normalize_node_text_lenient
    mp, mg = {}, set()
    for i, p in enumerate(predicted):
        for j, g in enumerate(gold):
            if j in mg:
                continue
            if (n(p["source"]) == n(g["source"]) and n(p["target"]) == n(g["target"])
                    and rel_match(pp, p["relation"], g["relation"])):
                mp[i] = "normalized"
                mg.add(j)
                break
    rp = [i for i in range(len(predicted)) if i not in mp]
    rg = [j for j in range(len(gold)) if j not in mg]
    if rp and rg:
        nodes = list({n(predicted[i][k]) for i in rp for k in ("source", "target")}
                     | {n(gold[j][k]) for j in rg for k in ("source", "target")})
        model = pp._get_embed_model()
        E = dict(zip(nodes, model.encode(nodes, normalize_embeddings=True)))
        cands = []
        for i in rp:
            p = predicted[i]
            for j in rg:
                g = gold[j]
                if not rel_match(pp, p["relation"], g["relation"]):
                    continue
                sc = min(node_score(n(p["source"]), n(g["source"]), E, theta),
                         node_score(n(p["target"]), n(g["target"]), E, theta))
                if sc > 0:
                    cands.append((sc, i, j))
        cands.sort(key=lambda x: -x[0])
        for sc, i, j in cands:
            if i in mp or j in mg:
                continue
            mp[i] = "semantic"
            mg.add(j)
    tp = len(mp)
    P = tp / len(predicted) if predicted else 0.0
    R = tp / len(gold) if gold else 0.0
    return {
        "precision": P, "recall": R, "f1": 2 * P * R / (P + R) if P + R else 0.0,
        "正解数": tp, "システム抽出数": len(predicted), "正解データ数": len(gold),
        "matched_pred": [predicted[i] for i in sorted(mp)],
        "unmatched_pred": [p for i, p in enumerate(predicted) if i not in mp],
        "unmatched_gold": [g for j, g in enumerate(gold) if j not in mg],
        "正解内訳": {"表記正規化一致": sum(1 for v in mp.values() if v == "normalized"),
                  "意味的類似度一致": sum(1 for v in mp.values() if v == "semantic")},
    }


def evaluate_triples_exact(pp, predicted, gold):
    """【主指標】トリプル完全一致（--eval-mode exact）。
    主語・目的語は表記正規化（_normalize_node_text_lenient：全角半角・「前記」・
    数量詞などの揺れを吸収）した上で完全一致、関係は rel_match（表記正規化・
    漢字部分一致・同義語グループ）で一致したものだけを正解とする。
    意味的類似度は使わない。"""
    n = pp._normalize_node_text_lenient
    mp, mg = set(), set()
    for i, p in enumerate(predicted):
        for j, g in enumerate(gold):
            if j in mg:
                continue
            if (n(p["source"]) == n(g["source"]) and n(p["target"]) == n(g["target"])
                    and rel_match(pp, p["relation"], g["relation"])):
                mp.add(i)
                mg.add(j)
                break
    tp = len(mp)
    P = tp / len(predicted) if predicted else 0.0
    R = tp / len(gold) if gold else 0.0
    return {
        "precision": P, "recall": R, "f1": 2 * P * R / (P + R) if P + R else 0.0,
        "正解数": tp, "システム抽出数": len(predicted), "正解データ数": len(gold),
        "matched_pred": [predicted[i] for i in sorted(mp)],
        "unmatched_pred": [p for i, p in enumerate(predicted) if i not in mp],
        "unmatched_gold": [g for j, g in enumerate(gold) if j not in mg],
    }
