# -*- coding: utf-8 -*-
"""
claim_segmenter.py
===================
【実験10】手がかり句による請求項の分割と、区間ごとのGiNZA解析。

新森ら（2004）「手がかり句を用いた特許請求項の構造解析」の考え方に基づき、
長い請求項を記述断片に分割してから、区間ごとに GiNZA 単体版
（patent_pipeline.analyze_claim_ginza_only）で解析する。

分割の手がかり（新森ら 表2・表3 を元にした）:
  ・出願人が入れた改行（新森らの調査では、改行位置の87%が記述断片の境界）
  ・「において、」「に於いて、」「であって、」（ジェプソン的形式の区切り）
  ・「名詞＋と、」（構成要素列挙形式の区切り）
  ・「動詞・助動詞の連用形＋、」（順次列挙形式・「前記Xは、…を含み、」の区切り）

各区間は、末尾の「と、」「、」を「。」に置き換えて独立した文として解析する。
「を備え、」のような構成要素の列挙を締めくくるだけの区間は解析しない
（題名と構成要素の関係は、請求項全体のGiNZA解析で既に取れているため）。

オプション（実験10b）:
  distribute=True : 「前記A及び前記Bのそれぞれは、…」を「前記Aは、…」「前記Bは、…」
                    の2つの区間に展開してから解析する。
  merge_enzai=True: GiNZA（SudachiPy）が「延在する」を「延」＋「在す」に誤って分割する
                    問題を、解析の前に1語へ結合して防ぐ。
"""
import re
from contextlib import contextmanager

_JEPSON_RE = re.compile(r"(において|に於いて|に於て|であって|にあたり|に当たり)[、，]")
_COMPOSE_ONLY_RE = re.compile(r"^(と)?[、，]?(を|とを)?[、，]?(備え|具備し|有し|含み|設け)(る|た|ている|てなる)?[、，]?$")
_DISTRIB_RE = re.compile(
    r"^(?P<coord>.+?)の(?P<each>それぞれ|各々|各)(?P<part>は|が|に|を|には|にも|も)(?P<rest>.*)$")
_NEW_TOPIC_RE = re.compile(r"^\s*(前記|該|当該|上記)?[^、。，]{1,40}?(は|が)[、，]")
_COORD_SPLIT_RE = re.compile(r"、|，|及び|および|並びに|ならびに|と")


def _split_line(pp, line):
    """1行を、GiNZAの品詞情報を使って手がかり句で区間に分ける。"""
    line = line.strip()
    if not line:
        return []
    doc = pp.nlp(line)
    cuts = []
    toks = list(doc)
    for i, t in enumerate(toks):
        if t.text not in ("、", "，") or i == 0 or i == len(toks) - 1:
            continue
        prev = toks[i - 1]
        infl = "".join(prev.morph.get("Inflection"))
        if prev.pos_ in ("VERB", "AUX") and "連用形" in infl:
            # 「〜設けられ、〜流路を有する多穴管と」のような修飾部の途中では切らない。
            # 新しい主題・主語（「前記Yは、」等）が続く場合だけ区切りとみなす。
            if _NEW_TOPIC_RE.match(line[t.idx + len(t.text):]):
                cuts.append(t.idx + len(t.text))
        elif prev.text == "と" and prev.pos_ in ("ADP", "CCONJ") and i >= 2 and toks[i - 2].pos_ in ("NOUN", "PROPN", "NUM", "SYM"):
            # 「AとBとの間に位置する」のような並列は構成要素の区切りではないので切らない
            if "との" not in line[t.idx + len(t.text):]:
                cuts.append(t.idx + len(t.text))
    for m in _JEPSON_RE.finditer(line):
        cuts.append(m.end())
    cuts = sorted(set(c for c in cuts if 0 < c < len(line)))
    parts, start = [], 0
    for c in cuts:
        parts.append(line[start:c])
        start = c
    parts.append(line[start:])
    return [p.strip() for p in parts if p.strip()]


def split_claim(pp, text):
    segs = []
    for line in re.split(r"[\r\n]+", text):
        segs.extend(_split_line(pp, line))
    return segs


def to_sentence(seg):
    """区間を独立した文にする。構成要素の列挙を締めくくるだけの区間はNone。"""
    s = seg.strip()
    if _COMPOSE_ONLY_RE.match(s):
        return None
    s = re.sub(r"[。．]$", "", s)
    s = _JEPSON_RE.sub(lambda m: "", s) if _JEPSON_RE.search(s[-6:] if len(s) > 6 else s) else s
    s = re.sub(r"とを?[、，]?$", "", s)
    s = re.sub(r"[、，]$", "", s)
    s = s.strip()
    if len(s) < 2:
        return None
    return s + "。"


def distribute(sent):
    """「前記A及び前記Bのそれぞれは、…」→「前記Aは、…」「前記Bは、…」"""
    m = _DISTRIB_RE.match(sent)
    if not m:
        return [sent]
    items = [x.strip() for x in _COORD_SPLIT_RE.split(m.group("coord")) if x.strip()]
    if len(items) < 2 or any(len(x) > 40 for x in items):
        return [sent]
    return [f"{x}{m.group('part')}{m.group('rest')}" for x in items]


_ENZAI_NAME = "exp10_merge_enzai"


def _ensure_enzai_component(pp):
    from spacy.language import Language

    if _ENZAI_NAME not in Language.factories:
        @Language.component(_ENZAI_NAME)
        def _merge(doc):
            with doc.retokenize() as rt:
                for i in range(len(doc) - 1):
                    if doc[i].text == "延" and doc[i + 1].text.startswith("在す"):
                        rt.merge(doc[i:i + 2], attrs={"POS": "VERB", "LEMMA": "延在する"})
            return doc
    if _ENZAI_NAME not in pp.nlp.pipe_names and _ENZAI_NAME not in pp.nlp.disabled:
        pp.nlp.add_pipe(_ENZAI_NAME, first=True)
        pp.nlp.disable_pipe(_ENZAI_NAME)


@contextmanager
def _enzai(pp, on):
    if not on:
        yield
        return
    _ensure_enzai_component(pp)
    pp.nlp.enable_pipe(_ENZAI_NAME)
    try:
        yield
    finally:
        pp.nlp.disable_pipe(_ENZAI_NAME)


def segment_relations(pp, text, distribute_each=False, merge_enzai=False):
    """区間ごとにGiNZA単体版で解析した関係を返す（type に区間解析の種類を付ける）。"""
    out = []
    with _enzai(pp, merge_enzai):
        for seg in split_claim(pp, text):
            sent = to_sentence(seg)
            if sent is None:
                continue
            sents = distribute(sent) if distribute_each else [sent]
            for s in sents:
                try:
                    _, rels = pp.analyze_claim_ginza_only(s)
                except Exception:  # noqa: BLE001
                    continue
                for r in rels:
                    r = dict(r)
                    r["seg_type"] = r.get("type", "?")
                    r["distributed"] = len(sents) > 1
                    out.append(r)
    return out
