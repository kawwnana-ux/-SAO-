# -*- coding: utf-8 -*-
"""
sao_selector.py
================
候補選別モデル（実験9）。

LLM直接抽出・GiNZA補完・GiNZA単体版の出力をすべて「候補」として集め、
候補の関係ごとに「正解である確率」を学習済みモデルで予測して、
確率がしきい値以上のものだけを採用する。同じ2つの構成要素の組（向きを
問わない）からは、確率が最も高い1件だけを採る。

実験2〜8では「このtypeのこの関係語はLLMに再確認させる」「この語が目的語
なら消す」といったルールを1つずつ足してきたが、ここではそれらの判断材料
（抽出元、関係語の種類、fan-out、題名かどうか、本文中の位置など）を
特徴量としてまとめて与え、どう組み合わせるかは学習に任せる。
LLMの呼び出しは抽出の1回だけ（実験2〜4の検証LLMは使わない）。

学習データ（sao_selector_train.npz）は、532件の正解データから作った
候補ごとの特徴量とラベル。評価時は交差検証の分割ごとに、その分割を除いた
請求項だけで学習したモデルを使う（学習に使った請求項で評価しない）。
"""
import re
from collections import Counter
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
TRAIN_FILE = HERE / "sao_selector_train.npz"

INVALID = {"複数", "互い", "こと", "もの", "場合", "状態", "様子", "全体", "一部", "両方", "それぞれ",
           "いずれか", "各々", "これ", "それ", "あれ", "ここ", "そこ", "一方", "他方",
           "それぞれの一方", "それぞれの他方", "少なくとも", "前記", "所定"}
SIMPLIFIED = set("收离构设为们这个从与际图电气压热导线发开关实现应该总数据还样进过对时")
SRC_KEYS = ["E1:llm_direct", "E1:claim_title_ginza", "E1:claim_title_ginza_conflict",
            "E1:ginza_has_fallback", "E1:ginza_has_fallback_conflict", "E1:attribute",
            "G:direct", "G:positional", "G:has", "LLMraw", "REV", "VERB"]
FORMATS = ["順次列挙形式", "構成要素列挙形式", "ジェプソン的形式"]
# LLMが関係語に中国語の簡体字を混ぜることがある（例：收容する）ので日本の字体に直す
SIMP = str.maketrans({"收": "収", "离": "離", "构": "構", "并": "並", "设": "設", "为": "為", "电": "電",
                      "气": "気", "压": "圧", "热": "熱", "导": "導", "线": "線", "发": "発", "开": "開",
                      "关": "関", "实": "実", "现": "現", "应": "応", "总": "総", "进": "進", "过": "過",
                      "对": "対", "时": "時", "连": "連", "结": "結", "层": "層", "极": "極", "块": "塊",
                      "从": "従", "个": "個", "际": "際", "图": "図", "样": "様", "动": "動", "驱": "駆",
                      "边": "辺", "侧": "側", "间": "間", "备": "備", "装": "装", "据": "拠", "变": "変",
                      "绝": "絶", "缘": "縁", "传": "伝", "递": "逓", "输": "輸", "给": "給", "调": "調",
                      "节": "節", "测": "測", "检": "検", "术": "術", "处": "処", "理": "理", "盖": "蓋",
                      "载": "載", "阳": "陽", "阴": "陰", "储": "貯", "续": "続", "转": "転", "换": "換"})
KEPT_INDEX = len(SRC_KEYS)  # 実験4の検証LLMを通ったかどうか（本モデルでは常に0として使う）


def rel_group(pp, rel):
    for i, group in enumerate(pp.RELATION_SYNONYM_GROUPS):
        if any((g in rel) if len(g) > 1 else (g == rel) for g in group):
            return i
    return -1


def claim_features(pp, info):
    """info = {"cands": [...], "tags": [...], "title": str|None, "cleaned": str, "format": str}"""
    n = pp._normalize_node_text_lenient
    surface = set(getattr(pp, "_SURFACE_LOCATION_WORDS", set()))
    n_groups = len(pp.RELATION_SYNONYM_GROUPS)
    cands = info["cands"]
    title = info["title"]
    tags = set(info["tags"])
    text = info["cleaned"]
    out_deg = Counter(c["source"] for c in cands)
    in_deg = Counter(c["target"] for c in cands)
    owners = Counter(c["target"] for c in cands if rel_group(pp, c["relation"]) == 0)
    pairs = Counter((c["source"], c["target"]) for c in cands)
    llm_pairs = {(c["source"], c["target"]) for c in cands
                 if "E1:llm_direct" in c["srcs"] or "LLMraw" in c["srcs"]}
    g_pairs = {(c["source"], c["target"]) for c in cands if any(s.startswith("G:") for s in c["srcs"])}
    rows = []
    for c in cands:
        s, r, t = c["source"], c["relation"], c["target"]
        f = [float(k in c["srcs"]) for k in SRC_KEYS]
        f += [float(c.get("kept", False)), float(len(c["srcs"]))]
        f += [float((s, t) in llm_pairs), float((s, t) in g_pairs), float((t, s) in llm_pairs),
              float((t, s) in g_pairs), float(pairs[(s, t)] - 1), float((t, s) in pairs)]
        g = rel_group(pp, r)
        f += [float(g == i) for i in range(-1, n_groups)]
        f += [float(len(r)), float("《" in r), float(r == "の"),
              float(bool(re.search(r"(される|られる|され|られ)$", r))),
              float(any(ch in SIMPLIFIED for ch in r))]
        for x in (s, t):
            f += [float(x == title), float(x in tags), float(len(x)), float("の" in x),
                  float(bool(re.search(r"\d|[０-９]", x))), float(x in INVALID or n(x) in INVALID),
                  float(x in surface), float(x in text)]
        f += [float(out_deg[s]), float(in_deg[t]), float(owners[t]), float(out_deg[t]), float(in_deg[s])]
        ps, pt = text.find(s), text.find(t)
        f += [float(ps), float(pt), float(abs(ps - pt) if ps >= 0 and pt >= 0 else -1),
              float(ps < pt if ps >= 0 and pt >= 0 else -1), float(len(text))]
        f += [float(len(tags)), float(len(cands))] + [float(info["format"] == x) for x in FORMATS]
        rows.append(f)
    X = np.array(rows, dtype=float) if rows else np.zeros((0, 1))
    if len(X):
        X[:, KEPT_INDEX] = 0.0
    return X


def build_candidates(ts, pp, text, llm_output=None, llm_cache=None, claim_id=None,
                     model=None, host=None):
    """候補を集める。LLMの呼び出しは抽出の1回だけ（llm_cacheがあればそれを使う）。"""
    tagged_text, t2t, tag_doc, tag_comps = ts.tag_components(text, pp)
    debug_out = {}
    kw = {} if model is None else {"model": model}
    if llm_output is not None:
        llm_cache = {"_": {"tagged_text_hash": ts._hash_text(tagged_text), "llm_output": llm_output}}
        claim_id = "_"
    _, e1 = ts.analyze_claim_llm_direct(text, pp=pp, host=host, llm_cache=llm_cache,
                                        claim_id=claim_id, debug_out=debug_out, **kw)
    raw = ts.extract_relations_from_llm_output(debug_out.get("llm_output", ""), t2t)
    try:
        _, g = pp.analyze_claim_ginza_only(text)
    except Exception:  # noqa: BLE001
        g = []
    cands = {}

    def add(r, src):
        rel = r["relation"].translate(SIMP)
        key = (r["source"], rel, r["target"])
        c = cands.setdefault(key, {"source": key[0], "relation": rel, "target": key[2],
                                   "srcs": [], "type": r.get("type", src)})
        if src not in c["srcs"]:
            c["srcs"].append(src)

    for r in e1:
        add(r, "E1:" + r["type"])
    for r in g:
        add(r, "G:" + r.get("type", "?"))
    for r in raw:
        add(r, "LLMraw")
    last_i = len(tag_doc) - 1
    while last_i > 0 and tag_doc[last_i].pos_ == "PUNCT":
        last_i -= 1
    tc = pp.find_component_by_token(tag_comps, last_i)
    return {"cands": list(cands.values()), "tags": sorted(set(t2t.values())),
            "title": tc["text"] if tc is not None else None,
            "cleaned": pp._clean_claim_text(text), "format": pp.classify_claim_format(text)}


def select(pp, info, prob, threshold):
    """確率の高い順に採用。同じ2つの構成要素の組（向きを問わない）からは1件だけ。"""
    n = pp._normalize_node_text_lenient
    out, seen = [], set()
    for i in np.argsort(-prob):
        if prob[i] < threshold:
            break
        c = info["cands"][i]
        key = frozenset((n(c["source"]), n(c["target"])))
        if key in seen:
            continue
        seen.add(key)
        out.append({"source": c["source"], "relation": c["relation"], "target": c["target"],
                    "type": c["srcs"][0].split(":")[-1] if c["srcs"] else "selected",
                    "prob": float(prob[i])})
    return out


class Selector:
    """学習データから選別モデルを作る。exclude_ids を渡すと、その請求項を除いて学習する
    （交差検証の評価用）。"""

    def __init__(self, exclude_ids=None, train_file=TRAIN_FILE):
        from sklearn.ensemble import HistGradientBoostingClassifier
        d = np.load(train_file, allow_pickle=False)
        X, Y, ids = d["X"], d["Y"], d["ids"]
        self.threshold = float(d["threshold"])
        if exclude_ids:
            keep = ~np.isin(ids, np.array(sorted(exclude_ids)))
            X, Y = X[keep], Y[keep]
        X = X.copy()
        X[:, KEPT_INDEX] = 0.0
        self.model = HistGradientBoostingClassifier(
            max_iter=300, learning_rate=0.05, max_leaf_nodes=31, min_samples_leaf=40,
            l2_regularization=1.0, early_stopping=False, random_state=0).fit(X, Y)

    def predict(self, pp, info):
        X = claim_features(pp, info)
        return self.model.predict_proba(X)[:, 1] if len(info["cands"]) else np.zeros(0)


def analyze_claim_selected(ts, pp, selector, text, threshold=None, **kw):
    info = build_candidates(ts, pp, text, **kw)
    prob = selector.predict(pp, info)
    rels = select(pp, info, prob, selector.threshold if threshold is None else threshold)
    return info, rels


def cv_folds(texts_by_id, n_folds=5, seed=42):
    """本文が同じ請求項を同じ分割に入れた、交差検証の分割（学習時と同じ分け方）。"""
    import random
    groups = {}
    for cid, text in texts_by_id.items():
        groups.setdefault("".join(text.split()), []).append(cid)
    glist = list(groups.values())
    random.Random(seed).shuffle(glist)
    return [[c for g in glist[i::n_folds] for c in g] for i in range(n_folds)]
