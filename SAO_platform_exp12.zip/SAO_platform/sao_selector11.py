# -*- coding: utf-8 -*-
"""
sao_selector11.py
==================
【実験11】ノードの粒度（「XのY」の結合）を、候補として選べるようにしたもの。

532件の正解データの分析（「XのY」でX・Yともにタグになっている1,341箇所）:
  ・正解で「XのY」が1つのノードになっている：526箇所
  ・正解ではYが単独のノードになっている　　：約310箇所
  → 無条件に結合すると約4割で誤るため、結合は規則で決めず「結合した候補」を
    追加して、実験9と同じ選別モデルにどちらを採るか判断させる。
  ・Yが本文で常に「〜のY」の形でしか出てこない場合は結合が約9割、単独でも
    出てくる場合は約8割（この情報を特徴量として与える）。
  ・正解に結合ノードがある場合、「X の XのY」という関係も約4分の1で付いている
    ので、その候補も追加する。

同じ箇所の「Y」と「XのY」は、どちらか一方しか採らない（選別時に同じ組とみなす）。

学習ラベルは主指標と同じ「トリプル完全一致」（node_match_eval.evaluate_triples_exact
と同じ基準）で付けている。主語・目的語ごとの意味的類似度（包含を一致とみなす）で
ラベルを付けると「Y」と「XのY」が同じ扱いになり、結合を学習できない（その条件では
F1が1.4pt下がった）。
実験9・10のコードと学習データには手を加えない。
"""
import re
from pathlib import Path

import numpy as np

import sao_selector as S
import sao_selector10 as S10

HERE = Path(__file__).resolve().parent
TRAIN_FILE = HERE / "sao_selector11_train.npz"


def merge_occurrences(info):
    """本文中の「XのY」（X・Yともにタグ）を探し、Y→[X, ...] を返す。"""
    text = info["cleaned"]
    tags = sorted(set(info["tags"]), key=len, reverse=True)
    owners = {}
    for X in tags:
        for Y in tags:
            if X != Y and (X + "の" + Y) in text:
                owners.setdefault(Y, [])
                if X not in owners[Y]:
                    owners[Y].append(X)
    return owners


def build_candidates(ts, pp, text, **kw):
    info = S10.build_candidates(ts, pp, text, variant="a", **kw)
    owners = merge_occurrences(info)
    text_c = info["cleaned"]
    index = {(c["source"], c["relation"], c["target"]): c for c in info["cands"]}
    base = {}

    def add(src, rel, tgt, srcs, bsrc, btgt):
        key = (src, rel, tgt)
        if key in index:
            c = index[key]
            for s in srcs:
                if s not in c["srcs"]:
                    c["srcs"].append(s)
            return
        c = {"source": src, "relation": rel, "target": tgt, "srcs": list(srcs), "type": "MRG"}
        info["cands"].append(c)
        index[key] = c
        base[key] = (bsrc, btgt)

    for c in list(info["cands"]):
        for side in ("source", "target"):
            Y = c[side]
            for X in owners.get(Y, []):
                M = X + "の" + Y
                other = c["target"] if side == "source" else c["source"]
                if other in (X, M):
                    continue
                new = dict(source=c["source"], target=c["target"])
                new[side] = M
                add(new["source"], c["relation"], new["target"],
                    [s for s in c["srcs"]] + ["MRG"], c["source"], c["target"])
    for Y, xs in owners.items():
        for X in xs:
            add(X, "の", X + "の" + Y, ["MRG:link"], X, Y)
    info["merge_owners"] = owners
    info["merge_base"] = {"|".join(k): list(v) for k, v in base.items()}
    info["y_always_no"] = {Y: (text_c.count(Y) == text_c.count("の" + Y)) for Y in owners}
    return info


def claim_features(pp, info):
    X = S10.claim_features(pp, info)
    if not len(info["cands"]):
        return X
    owners = info.get("merge_owners", {})
    merged_nodes = {X_ + "の" + Y: Y for Y, xs in owners.items() for X_ in xs}
    extra = []
    for c in info["cands"]:
        ms = [merged_nodes[x] for x in (c["source"], c["target"]) if x in merged_nodes]
        ys = [x for x in (c["source"], c["target"]) if x in owners]
        y = ms[0] if ms else (ys[0] if ys else None)
        extra.append([
            float("MRG" in c["srcs"]), float("MRG:link" in c["srcs"]), float(bool(ms)), float(bool(ys)),
            float(info.get("y_always_no", {}).get(y, False)) if y else -1.0,
            float(len(owners.get(y, []))) if y else 0.0,
            float(bool(re.search(r"\d|[０-９一二三四五六七八九]", y))) if y else -1.0,
            float(len(y)) if y else 0.0,
        ])
    return np.hstack([X, np.array(extra, dtype=float)])


def select(pp, info, prob, threshold):
    """実験9と同じ選び方。ただし「XのY」と「Y」は同じノードとみなして組の重複を判定する。"""
    n = pp._normalize_node_text_lenient
    owners = info.get("merge_owners", {})
    canon = {X + "の" + Y: Y for Y, xs in owners.items() for X in xs}
    out, seen = [], set()
    for i in np.argsort(-prob):
        if prob[i] < threshold:
            break
        c = info["cands"][i]
        key = frozenset((n(canon.get(c["source"], c["source"])), n(canon.get(c["target"], c["target"]))))
        if key in seen:
            continue
        seen.add(key)
        out.append({"source": c["source"], "relation": c["relation"], "target": c["target"],
                    "type": c["srcs"][0].split(":")[-1] if c["srcs"] else "selected",
                    "prob": float(prob[i])})
    return out


class Selector(S.Selector):
    def __init__(self, exclude_ids=None, train_file=TRAIN_FILE):
        super().__init__(exclude_ids=exclude_ids, train_file=train_file)

    def predict(self, pp, info):
        X = claim_features(pp, info)
        return self.model.predict_proba(X)[:, 1] if len(info["cands"]) else np.zeros(0)


def analyze_claim_selected(ts, pp, selector, text, threshold=None, **kw):
    info = build_candidates(ts, pp, text, **kw)
    prob = selector.predict(pp, info)
    return info, select(pp, info, prob, selector.threshold if threshold is None else threshold)
