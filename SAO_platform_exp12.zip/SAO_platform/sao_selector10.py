# -*- coding: utf-8 -*-
"""
sao_selector10.py
==================
【実験10】実験9（sao_selector.py）の候補に、手がかり句で分割した区間ごとの
GiNZA解析（claim_segmenter.py）の結果を追加した候補選別モデル。
実験9のコード・学習データには一切手を加えず、候補と特徴量を足すだけにしている。
"""
from pathlib import Path

import numpy as np

import claim_segmenter as CS
import sao_selector as S

HERE = Path(__file__).resolve().parent
TRAIN_FILE = HERE / "sao_selector10a_train.npz"
SEG_KEYS = ["GS:direct", "GS:positional", "GS:has", "GS:distrib"]


def build_candidates(ts, pp, text, variant="a", **kw):
    """variant="a"（採用）: 分割のみ。"b": 分割＋「それぞれ」の展開＋「延在」の結合（効果なし）。"""
    info = S.build_candidates(ts, pp, text, **kw)
    rels = CS.segment_relations(pp, text, distribute_each=(variant == "b"), merge_enzai=(variant == "b"))
    index = {(c["source"], c["relation"], c["target"]): c for c in info["cands"]}
    for r in rels:
        rel = r["relation"].translate(S.SIMP)
        key = (r["source"], rel, r["target"])
        c = index.get(key)
        if c is None:
            c = {"source": key[0], "relation": rel, "target": key[2], "srcs": [], "type": "GS:" + r["seg_type"]}
            info["cands"].append(c)
            index[key] = c
        for src in ["GS:" + r["seg_type"]] + (["GS:distrib"] if r.get("distributed") else []):
            if src not in c["srcs"]:
                c["srcs"].append(src)
    return info


def claim_features(pp, info):
    X = S.claim_features(pp, info)
    if not len(info["cands"]):
        return X
    cands = info["cands"]
    gs_pairs = {(c["source"], c["target"]) for c in cands if any(s.startswith("GS:") for s in c["srcs"])}
    extra = []
    for c in cands:
        f = [float(k in c["srcs"]) for k in SEG_KEYS]
        f += [float((c["source"], c["target"]) in gs_pairs), float((c["target"], c["source"]) in gs_pairs),
              float(sum(s.startswith("GS:") for s in c["srcs"]))]
        extra.append(f)
    return np.hstack([X, np.array(extra, dtype=float)])


class Selector(S.Selector):
    """実験10の選別モデル。学習データと特徴量だけが実験9と異なる。"""

    def __init__(self, exclude_ids=None, train_file=TRAIN_FILE):
        super().__init__(exclude_ids=exclude_ids, train_file=train_file)

    def predict(self, pp, info):
        X = claim_features(pp, info)
        return self.model.predict_proba(X)[:, 1] if len(info["cands"]) else np.zeros(0)


def analyze_claim_selected(ts, pp, selector, text, threshold=None, **kw):
    info = build_candidates(ts, pp, text, **kw)
    prob = selector.predict(pp, info)
    rels = S.select(pp, info, prob, selector.threshold if threshold is None else threshold)
    return info, rels
