# -*- coding: utf-8 -*-
"""
eval_translate_sao.py
======================
translate_sao.py の厳格F1を、既存のGiNZA版（patent_pipeline.py）と
全く同じ評価基準（evaluate_triples / RELATION_SYNONYM_GROUPS）で測定する。

2つのモードがある（--mode）:
  llm_direct（デフォルト）: 「タグ化 → タグ付き日本語のままLLMにSAOを
      直接出力させる → 日本語に逆変換」方式。英訳を挟まないので、
      翻訳段とSAO抽出段の誤差が混ざらない。
  translate: 従来の「タグ化 → Ollama/DeepL翻訳 → 英語で依存構造解析 →
      日本語に逆変換」方式（比較用に残している）。

【方針転換】以前は「評価方法を甘くして数値を良く見せることは絶対にしない」
という方針の下、evaluate_triples（source/targetの完全一致必須）だけを
使っていた。その後、ユーザーの明示的な判断により「意味が伝わっていれば
正解でよい」という基準に変更し、既定の評価をevaluate_triples_lenient
（①表記・字体の正規化、②数量詞・修飾語の除去、③それでも不一致なら
埋め込みモデルによる意味的類似度）に切り替えた（--eval-mode strictで
従来の厳格評価にも戻せる。GiNZA初期0.277→改良0.421という過去の数字は
すべて厳格評価によるものなので、そちらと比較する際は必ず--eval-mode strict
を使うこと）。

使い方（自分のPC上、Ollamaが起動している状態で）:
    pip install spacy ollama
    python -m spacy download en_core_web_sm
    python3 eval_translate_sao.py --pipeline-dir /path/to/real_app --data-dir /path/to/gold_data --limit 20

532件全部を回すとLLM呼び出しが大量に発生し、1クレームあたり数十秒〜
1分程度かかることがあるため、全体では数時間規模になりうる。そのため
本スクリプトは毎クレーム処理後に --out へ結果を保存しており、
--resume を付けて再実行すると、既に --out に保存済みのクレームは
スキップして続きから再開できる（PCのスリープ・ネットワーク切断・
途中終了などで作業が失われないようにするため）。
--debug を付けるとクレームごとにタグ付き原文・LLM出力（または英訳）・
抽出結果を表示する。
"""
import argparse
import json
import sys
import time
from collections import Counter
from pathlib import Path

import translate_sao as ts


def _aggregate(per_claim):
    """per_claimのリストからMICRO/MACRO集計を計算する（再開時も毎回この
    リストから計算し直すので、二重カウントの心配がない）。"""
    n = len(per_claim) or 1
    total_tp = sum(c["正解数"] for c in per_claim)
    total_pred = sum(c["システム抽出数"] for c in per_claim)
    total_gold = sum(c["正解データ数"] for c in per_claim)
    micro_p = total_tp / total_pred if total_pred else 0.0
    micro_r = total_tp / total_gold if total_gold else 0.0
    micro_f1 = 2 * micro_p * micro_r / (micro_p + micro_r) if micro_p + micro_r else 0.0
    macro_p = sum(c["precision"] for c in per_claim) / n
    macro_r = sum(c["recall"] for c in per_claim) / n
    macro_f1 = sum(c["f1"] for c in per_claim) / n
    return {
        "micro": {"precision": micro_p, "recall": micro_r, "f1": micro_f1},
        "macro": {"precision": macro_p, "recall": macro_r, "f1": macro_f1},
    }


_FALLBACK_TYPES_FOR_TABLE = {
    "claim_title_ginza", "ginza_has_fallback", "attribute",
    # 【LLM無言／LLM矛盾の分離】claim_title_ginza_conflict / ginza_has_fallback_conflict は、
    # 同じ(source, target)についてLLMが既に別の（同義語ではない）関係を出している
    # ケース。無言タイプ（LLMが何も出していないケース）とTP/FP/Precisionを
    # 分けて見られるようにするため、表には別の行として並べる。
    "claim_title_ginza_conflict", "ginza_has_fallback_conflict",
}


def _aggregate_type_relation(per_claim):
    """全claimのtp_fp_by_type_relationを合算し、(type, 関係語)ごとの
    TP/FP/Precisionの表を作る。claim_title_ginza / ginza_has_fallback /
    attribute（GiNZA由来で語彙が限られたフォールバック）だけに絞る
    （llm_direct/translateはLLMの自由な言い換えで関係語のバリエーションが
    膨大になり、個別の採用/不採用ルールを作る対象として実用的ではないため）。
    Precisionが低い順（不採用候補が先）に並べて返す。"""
    combined = {}
    for c in per_claim:
        for tr_key, counts in c.get("tp_fp_by_type_relation", {}).items():
            combined.setdefault(tr_key, {"tp": 0, "fp": 0})
            combined[tr_key]["tp"] += counts["tp"]
            combined[tr_key]["fp"] += counts["fp"]

    rows = []
    for tr_key, counts in combined.items():
        type_name, _, relation = tr_key.partition("|")
        if type_name not in _FALLBACK_TYPES_FOR_TABLE:
            continue
        tp, fp = counts["tp"], counts["fp"]
        n = tp + fp
        rows.append({
            "type": type_name, "relation": relation, "tp": tp, "fp": fp,
            "precision": tp / n if n else 0.0,
        })
    rows.sort(key=lambda r: r["precision"])
    return rows


def _load_llm_cache(cache_path):
    """LLM生出力キャッシュを読み込む。ファイルが無い/壊れている場合は
    空のキャッシュから始める（キャッシュは常にベストエフォートで、
    失敗しても評価自体は最初からOllamaを呼んで進められる）。"""
    if cache_path is None:
        return None
    p = Path(cache_path)
    if not p.exists():
        return {}
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        return data.get("cache", {})
    except Exception as e:  # noqa: BLE001
        print(f"--llm-cache: {p} の読み込みに失敗したため、空のキャッシュから始めます（{e}）")
        return {}


def _save_llm_cache(cache_path, llm_cache):
    """LLM生出力キャッシュを保存する（1件処理するたびに呼び、途中終了しても
    それまでにOllamaを呼んだ分は失わずに再利用できるようにする）。"""
    if cache_path is None:
        return
    with open(cache_path, "w", encoding="utf-8") as f:
        json.dump({"cache": llm_cache}, f, ensure_ascii=False, indent=1)


def _lenient_match_details(pp, predicted, gold, semantic_threshold, use_semantic):
    """evaluate_triples_lenientと同じ手順・同じ順序で対応付けを行い、
    どの抽出がどの正解に、どの方法（表記正規化／意味的類似度）と類似度で
    対応付いたかを記録する（評価結果そのものは変えない。呼び出し側で
    正解数が公式の評価と一致することを確認している）。"""
    n = pp._normalize_node_text_lenient

    def rel_match(p_rel, g_rel):
        if p_rel == g_rel:
            return True
        pn = pp._normalize_relation_for_match(p_rel)
        gn = pp._normalize_relation_for_match(g_rel)
        if pn == gn or pn in gn or gn in pn:
            return True
        return pp._relation_synonym_match(p_rel, g_rel)

    matched = {}
    matched_gold = set()
    for pi, p in enumerate(predicted):
        for gi, g in enumerate(gold):
            if gi in matched_gold:
                continue
            if (n(p["source"]) == n(g["source"]) and n(p["target"]) == n(g["target"])
                    and rel_match(p["relation"], g["relation"])):
                matched[pi] = (gi, "normalized", None)
                matched_gold.add(gi)
                break

    remaining_pred = [pi for pi in range(len(predicted)) if pi not in matched]
    remaining_gold = [gi for gi in range(len(gold)) if gi not in matched_gold]
    if use_semantic and remaining_pred and remaining_gold:
        try:
            model = pp._get_embed_model()

            def text(r):
                return pp._triple_to_text((n(r["source"]), r["relation"], n(r["target"])))

            emb_p = model.encode([text(predicted[i]) for i in remaining_pred], normalize_embeddings=True)
            emb_g = model.encode([text(gold[i]) for i in remaining_gold], normalize_embeddings=True)
            sim = emb_p @ emb_g.T
            cands = [(sim[a, b], a, b) for a in range(sim.shape[0]) for b in range(sim.shape[1])]
            cands.sort(key=lambda x: -x[0])
            used_b = set()
            for s, a, b in cands:
                if s < semantic_threshold:
                    break
                pi, gi = remaining_pred[a], remaining_gold[b]
                if pi in matched or b in used_b or gi in matched_gold:
                    continue
                matched[pi] = (gi, "semantic", float(s))
                matched_gold.add(gi)
                used_b.add(b)
        except Exception:  # noqa: BLE001 -- 公式評価側と同じく、使えなければ意味的一致なしで扱う
            pass

    return [
        {"pred": predicted[pi], "gold": gold[gi], "method": method, "similarity": s}
        for pi, (gi, method, s) in sorted(matched.items())
    ]


def _save(out_path, per_claim, args, elapsed, done):
    agg = _aggregate(per_claim)
    type_relation_table = _aggregate_type_relation(per_claim)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "eval_mode": args.eval_mode,
                "semantic_threshold": (args.semantic_threshold if args.eval_mode == "lenient"
                                       else args.node_threshold if args.eval_mode == "node" else None),
                "micro": agg["micro"],
                "macro": agg["macro"],
                "type_relation_table": type_relation_table,
                "per_claim": per_claim,
                "elapsed_sec": elapsed,
                "model": args.model,
                "done": done,  # False=まだ途中（--resumeで再開可能）, True=全件完了
            },
            f, ensure_ascii=False, indent=1,
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--pipeline-dir", required=True,
        help="patent_pipeline.py（evaluate_triples等）が置いてあるディレクトリ",
    )
    parser.add_argument(
        "--data-dir", required=True,
        help="claims_532_for_gold.json / gold_sao_532_merged.json が置いてあるディレクトリ",
    )
    parser.add_argument("--model", default=ts.DEFAULT_MODEL)
    parser.add_argument("--host", default=None)
    parser.add_argument(
        "--mode", default="llm_direct", choices=["llm_direct", "translate", "selected", "selected10", "selected11", "selected12"],
        help="selected12: 【実験12・推奨】selected11の候補に、係り受けに基づく汎用の候補"
             "（述語にかかる構成要素どうしの組、dep_pairs.py）を追加し、2段階の選別モデルで選ぶ"
             "（sao_selector12.py）。1組から採る関係の数も交差検証の内側で選んだ値を使う。"
             "selected11: 【実験11】selected10の候補に「XのY」を結合したノードの候補を"
             "追加し、トリプル完全一致の基準で学習した選別モデル（sao_selector11.py）。"
             "selected10: 【実験10】selectedの候補に、手がかり句で分割した区間ごとの"
             "GiNZA解析（claim_segmenter.py、新森ら2004に基づく）を追加したもの（sao_selector10.py）。"
             "selected: 【実験9】候補選別モデル（sao_selector.py）。LLM直接抽出・GiNZA補完・"
             "GiNZA単体版の出力を候補として集め、学習済みモデルで正解の確率を予測して選ぶ。"
             "評価では交差検証の分割ごとに、その分割を除いた請求項だけで学習したモデルを使う。"
             "llm_direct（デフォルト）: 英訳を挟まず、タグ付き日本語をそのままLLMに渡して"
             "SAOを直接抽出する。translate: 従来の「タグ付き日本語→英訳→英語で"
             "依存構造解析」方式（--backend/--deepl-keyはこちらでのみ使う）。",
    )
    parser.add_argument("--backend", default="ollama", choices=["ollama", "deepl"],
                         help="--mode translate専用。翻訳エンジン。"
                              "deeplはDEEPL_API_KEY環境変数（または--deepl-key）が必要")
    parser.add_argument("--deepl-key", default=None, help="DeepL APIキー（省略時はDEEPL_API_KEY環境変数）")
    parser.add_argument("--limit", type=int, default=10, help="評価するクレーム数（先頭からN件）")
    parser.add_argument(
        "--format", default=None,
        choices=["順次列挙形式", "構成要素列挙形式", "ジェプソン的形式"],
        help="classify_claim_format()でこの表現形式に分類されたクレームだけに絞り込む"
             "（--limitは絞り込んだ後の件数に適用される）。省略時は絞り込まない。",
    )
    parser.add_argument("--out", default="eval_translate_result.json")
    parser.add_argument("--debug", action="store_true", help="タグ付き原文・英訳・抽出結果を表示する")
    parser.add_argument(
        "--eval-mode", default="lenient", choices=["lenient", "strict", "node", "exact"],
        help="exact: 【主指標】トリプル完全一致（主語・目的語は表記正規化後に完全一致、関係は"
             "表記正規化・漢字部分一致・同義語。意味的類似度は使わない。node_match_eval.py）。"
             "node: 主語どうし・目的語どうしを比べる評価（node_match_eval.py、閾値は"
             "--node-threshold）。"
             "lenient（デフォルト）: 表記正規化＋意味的類似度による緩い評価"
             "（evaluate_triples_lenient）。strict: 従来のsource/target完全一致"
             "（evaluate_triples）。GiNZA初期0.277→改良0.421と比較する場合はstrictを使う。",
    )
    parser.add_argument(
        "--semantic-threshold", type=float, default=0.75,
        help="--eval-mode lenientでの、埋め込みモデルによる意味的一致とみなす"
             "コサイン類似度の閾値（0〜1）。",
    )
    parser.add_argument(
        "--node-threshold", type=float, default=0.9,
        help="--eval-mode nodeでの、主語どうし・目的語どうしの埋め込み類似度の閾値。",
    )
    parser.add_argument(
        "--no-semantic", action="store_true",
        help="--eval-mode lenientで、埋め込みモデルを使わず表記正規化のみで評価する"
             "（sentence-transformersのインストール・モデルダウンロードが不要になる）。",
    )
    parser.add_argument(
        "--resume", action="store_true",
        help="--outに既存の結果ファイルがあれば読み込み、そこに含まれるクレームIDは"
             "スキップして続きから実行する。532件のような長時間の実行を、"
             "途中で中断されても失わずに再開するためのオプション。",
    )
    parser.add_argument(
        "--save-details", action="store_true",
        help="評価方法の検証用。各クレームについて、全抽出結果（predicted）、"
             "どの抽出がどの正解にどの方法（表記正規化／意味的類似度）と類似度で"
             "一致したか（match_details）、厳格評価の結果（strict）も--outに保存する。"
             "評価の数値そのものは変わらない。",
    )
    parser.add_argument(
        "--verify-risky-ginza", action="store_true",
        help="【実験2：条件付きGiNZA（検証型）】--mode llm_direct専用。1請求項内で"
             "ginza_has_fallback|有する候補が--risk-threshold件以上生成された"
             "場合だけ、その候補群をLLMに個別確認させ、確認できなかった候補を"
             "除外する。それ未満の通常のケースは変更しない。省略時（デフォルト）"
             "は実験1のbaselineと完全に同じ挙動。",
    )
    parser.add_argument(
        "--risk-threshold", type=int, default=ts._DEFAULT_RISK_THRESHOLD,
        help=f"--verify-risky-ginza時の閾値（1請求項あたりのginza_has_fallback|"
             f"有する候補数）。デフォルト{ts._DEFAULT_RISK_THRESHOLD}は、532件"
             f"baselineの分析（gh_n>=16の13件がPrecision25.3%%で候補総数の約4割を"
             f"占めていた）に基づく。",
    )
    parser.add_argument(
        "--verify-fanout", action="store_true",
        help="【実験8：ginza_has_fallback|有するのfan-out型検証】--mode llm_direct"
             "専用。--verify-risky-ginza（gh_n＝1請求項あたりの候補総数）とは別の、"
             "より細かい粒度の指標。ginza_has_fallback|有するの候補を同じsourceで"
             "グループ化し、1つのsourceが--fanout-risk-threshold件以上の別々の"
             "targetと繋がっている場合だけ、そのグループをLLMに個別確認させる"
             "（例：「係合爪の各々」が「第１部材」「係合爪」「半導体装置」等、"
             "6つの無関係なtargetに繋がってしまうようなケースを狙う）。"
             "--verify-risky-ginzaと独立に指定でき、併用もできる（両方の基準の"
             "いずれかに該当する候補が1回のLLM呼び出しでまとめて検証される）。"
             "省略時（デフォルト）は実験1〜7のbaselineと完全に同じ挙動。",
    )
    parser.add_argument(
        "--fanout-risk-threshold", type=int, default=ts._DEFAULT_FANOUT_RISK_THRESHOLD,
        help=f"--verify-fanout時の閾値（同一source内での、別々のtarget数）。"
             f"デフォルト{ts._DEFAULT_FANOUT_RISK_THRESHOLD}は、raw候補×gold_sao_"
             f"532_merged.jsonのシミュレーション分析（fan-out=1で55.9%%、2で"
             f"66.5%%、3で53.1%%、4で49.2%%、5で27.3%%、6以上で20.9%%）に基づく。",
    )
    parser.add_argument(
        "--verify-extra-risky", action="store_true",
        help="【実験3：検証型の対象拡張】--mode llm_direct専用。"
             "ginza_has_fallback|有する（--verify-risky-ginza）以外にも、"
             "532件baselineの精査で見つかった危険な(type,関係語)——"
             "claim_title_ginza|有する（候補--claim-title-risk-threshold件以上）、"
             "attribute|の（常に）、llm_direct側の「超える」「方向」"
             "「より小さい」「位置する」（常に）——を同じLLM再確認の仕組みで"
             "検証する。--verify-risky-ginzaと独立に指定でき、併用もできる。",
    )
    parser.add_argument(
        "--claim-title-risk-threshold", type=int, default=ts._DEFAULT_CLAIM_TITLE_RISK_THRESHOLD,
        help=f"【実験5：既存GiNZAルールの閾値調整】--verify-extra-risky時の、"
             f"claim_title_ginza|有するの検証閾値（1請求項あたりの候補数）。"
             f"デフォルト{ts._DEFAULT_CLAIM_TITLE_RISK_THRESHOLD}は実験3の値。"
             f"実験4後の残存FP分析で、閾値のすぐ下（候補数10〜13件）にも"
             f"Precision72.0%%程度の危険な塊が残っていることが判明したため、"
             f"10まで下げて適用範囲を広げられるようにした。",
    )
    parser.add_argument(
        "--verify-cache", default=None,
        help="--verify-risky-ginza / --verify-extra-risky時のLLM検証呼び出し用"
             "キャッシュファイル（--llm-cacheとは別ファイルで管理する）。"
             "仕組みは--llm-cacheと同じ。",
    )
    parser.add_argument(
        "--filter-invalid-targets", action="store_true",
        help="【実験4：target無条件フィルタ】--mode llm_direct専用。type・relationを"
             "問わず、targetがts._INVALID_TARGET_WORDS（「複数」「互い」等、"
             "gold_sao_532_merged.json全10,497件中に一件も出現しないと確認済みの"
             "18語）に完全一致する関係を一律除去する。LLM呼び出し不要"
             "（Ollama非依存の後処理のみ）。--verify-risky-ginza / "
             "--verify-extra-risky とは独立に併用できる。デフォルト（省略時）は"
             "実験1〜3のbaselineと完全に同じ挙動。",
    )
    parser.add_argument(
        "--filter-redundant-root-ownership", action="store_true",
        help="【実験7：クレームタイトルによる二重所有の除去】--mode llm_direct専用。"
             "sourceがクレームタイトル相当の構成要素（claim_title_ginza判定に使う"
             "ものと同じ）である「有する」系関係のうち、同じtargetを既に別の"
             "（より具体的な）構成要素が所有しているものを、過大包摂として一律"
             "除去する。LLM呼び出し不要（Ollama非依存の後処理のみ）。実験4の"
             "targetフィルタとは異なる根拠（target自体ではなく既存の所有関係との"
             "突き合わせ）に基づく決定的フィルタで、--filter-invalid-targets等"
             "とは独立に併用できる。デフォルト（省略時）は実験1〜6のbaselineと"
             "完全に同じ挙動。",
    )
    parser.add_argument(
        "--llm-cache", default=None,
        help="【実験2以降のためのLLM生出力キャッシュ】--mode llm_direct専用。"
             "指定したパスのJSONファイルにクレームIDごとのOllama生出力（GiNZA"
             "補完前）を保存し、次回以降は同じクレームでOllamaを呼ばずに再利用する。"
             "GiNZA側のロジック（_apply_ginza_fallback_and_normalize等）だけを"
             "変更した実験を、Ollamaの再呼び出しなしで再評価できるようにするため。"
             "ファイルが存在しない場合は空のキャッシュから始めて新規作成し、既存の"
             "場合は追記（既存エントリは上書きされない限り保持）する。--out（評価"
             "結果）とは別ファイルで管理する。省略時（デフォルト）は今まで通り"
             "毎クレーム必ずOllamaを呼ぶ（挙動は変わらない）。",
    )
    args = parser.parse_args()

    sys.path.insert(0, args.pipeline_dir)
    import patent_pipeline as pp  # 厳格F1の判定ロジックはGiNZA版と共通のものを使う

    data_dir = Path(args.data_dir)
    with open(data_dir / "claims_532_for_gold.json", encoding="utf-8") as f:
        claims = json.load(f)
    with open(data_dir / "gold_sao_532_merged.json", encoding="utf-8") as f:
        gold_all = json.load(f)

    if args.format:
        claims = [c for c in claims if pp.classify_claim_format(c["text"]) == args.format]
        print(f"表現形式「{args.format}」に絞り込み: {len(claims)}件")

    claims = claims[: args.limit] if args.limit else claims

    out_path = Path(args.out)
    per_claim = []
    done_ids = set()
    if args.resume and out_path.exists():
        try:
            with open(out_path, encoding="utf-8") as f:
                prev = json.load(f)
            per_claim = prev.get("per_claim", [])
            done_ids = {c["id"] for c in per_claim}
            print(f"--resume: {out_path} から完了済み{len(done_ids)}件を読み込みました。続きから実行します。")
        except Exception as e:  # noqa: BLE001 -- 読み込み失敗時は最初からでも進められるようにする
            print(f"--resume: {out_path} の読み込みに失敗したため、最初から実行します（{e}）")
            per_claim = []
            done_ids = set()

    targets = [c for c in claims if c["id"] not in done_ids]
    n_target = len(targets)
    t0 = time.time()
    n_done_this_run = 0

    llm_cache = _load_llm_cache(args.llm_cache)
    if llm_cache is not None:
        print(f"--llm-cache: {args.llm_cache}（既存{len(llm_cache)}件を読み込み）")
    verify_cache = _load_llm_cache(args.verify_cache)
    if verify_cache is not None:
        print(f"--verify-cache: {args.verify_cache}（既存{len(verify_cache)}件を読み込み）")
    if args.verify_risky_ginza:
        print(f"--verify-risky-ginza有効（閾値: gh_n>={args.risk_threshold}）")
    if args.verify_fanout:
        print(f"--verify-fanout有効（閾値: 同一source内のtarget数>={args.fanout_risk_threshold}）")
    extra_risk_rules = ts._build_extra_risk_rules(args.claim_title_risk_threshold) if args.verify_extra_risky else None
    if args.verify_extra_risky:
        rules_desc = ", ".join(f"{r['type']}|{r['relation']}(閾値{r['threshold']})" for r in extra_risk_rules)
        print(f"--verify-extra-risky有効: {rules_desc}")
    if args.filter_invalid_targets:
        words_desc = "、".join(sorted(ts._INVALID_TARGET_WORDS))
        print(f"--filter-invalid-targets有効: target完全一致で無条件除去する語 = {words_desc}")
    if args.filter_redundant_root_ownership:
        print("--filter-redundant-root-ownership有効: クレームタイトルによる二重所有を除去")

    if args.mode in ("selected", "selected10", "selected11", "selected12"):
        import sao_selector
        import sao_selector10
        import sao_selector11
        if args.mode == "selected12":
            import sao_selector12
        folds = sao_selector.cv_folds({c["id"]: c["text"] for c in json.load(
            open(data_dir / "claims_532_for_gold.json", encoding="utf-8"))})
        fold_of = {cid: k for k, f in enumerate(folds) for cid in f}
        import numpy as _np
        _sel_mod = {"selected": sao_selector, "selected10": sao_selector10,
                    "selected11": sao_selector11,
                    "selected12": sao_selector12 if args.mode == "selected12" else None}[args.mode]
        _train = _np.load(_sel_mod.TRAIN_FILE, allow_pickle=False)
        fold_threshold = [float(t) for t in _train["fold_thresholds"]]
        print(f"--mode {args.mode}: 交差検証の5分割ごとに選別モデルを学習しています…")
        if args.mode == "selected12":
            # 2段目の構造特徴は、その分割の学習用請求項だけで作ったもの（X2_fold{k}）を使う
            fold_selector = [_sel_mod.Selector(exclude_ids=set(f), fold=k) for k, f in enumerate(folds)]
        else:
            fold_selector = [_sel_mod.Selector(exclude_ids=set(f)) for f in folds]
        print(f"  分割ごとのしきい値: {fold_threshold}")
    if args.eval_mode in ("node", "exact"):
        import node_match_eval

    for c in targets:
        cid = c["id"]
        try:
            if args.mode in ("selected", "selected10", "selected11", "selected12"):
                selector = fold_selector[fold_of[cid]]
                extra = {}
                if args.mode == "selected12" and selector.fold_max_per_pair:
                    extra["max_per_pair"] = selector.fold_max_per_pair[fold_of[cid]]
                _, predicted = _sel_mod.analyze_claim_selected(
                    ts, pp, selector, c["text"], threshold=fold_threshold[fold_of[cid]],
                    llm_cache=llm_cache, claim_id=cid, model=args.model, host=args.host, **extra)
            elif args.mode == "translate":
                _, predicted = ts.analyze_claim_translate(
                    c["text"], model=args.model, host=args.host, pp=pp, debug=args.debug,
                    backend=args.backend, deepl_api_key=args.deepl_key,
                )
            else:
                _, predicted = ts.analyze_claim_llm_direct(
                    c["text"], model=args.model, host=args.host, pp=pp, debug=args.debug,
                    llm_cache=llm_cache, claim_id=cid,
                    verify_risky_ginza=args.verify_risky_ginza, risk_threshold=args.risk_threshold,
                    verify_fanout=args.verify_fanout, fanout_risk_threshold=args.fanout_risk_threshold,
                    extra_risk_rules=extra_risk_rules,
                    verify_cache=verify_cache,
                    filter_invalid_targets=args.filter_invalid_targets,
                    filter_redundant_root_ownership=args.filter_redundant_root_ownership,
                )
        except Exception as e:  # noqa: BLE001 -- 1件の失敗で全体を止めない
            print(f"[{cid}] エラーのためスキップ: {e}")
            continue
        gold = gold_all[cid]
        if args.eval_mode == "exact":
            metrics = node_match_eval.evaluate_triples_exact(pp, predicted, gold)
        elif args.eval_mode == "node":
            metrics = node_match_eval.evaluate_triples_node(pp, predicted, gold, theta=args.node_threshold)
        elif args.eval_mode == "lenient":
            metrics = pp.evaluate_triples_lenient(
                predicted, gold, lenient_relation_match=True,
                semantic_threshold=args.semantic_threshold,
                use_semantic=not args.no_semantic,
            )
        else:
            metrics = pp.evaluate_triples(predicted, gold, lenient_relation_match=True)
        # unmatched_gold/unmatched_pred は従来 --debug 時のみ画面表示していたが、
        # 532件規模では画面出力を後から見返すのは非現実的なので、常に --out の
        # JSONへ保存する（誤抽出の傾向を、実行後にファイルから集計できるようにするため）。
        keep_keys = [
            "precision", "recall", "f1", "正解数", "システム抽出数", "正解データ数",
            "unmatched_gold", "unmatched_pred",
        ]
        if "正解内訳" in metrics:
            keep_keys.append("正解内訳")

        # 【type×関係語ごとのTP/FP内訳】translate_sao.pyの各関係には、どの処理が
        # 作ったかを示す"type"（llm_direct / claim_title_ginza /
        # ginza_has_fallback / attribute / translate 等）が付いている。
        # 「GiNZAフォールバックを丸ごとON/OFFする」のではなく、「(type, 関係語)の
        # 組み合わせごとに、これまでの実測でPrecision（TP/(TP+FP)）が高ければ
        # 採用し、低ければ不採用にする」という、より粒度の細かい判断をしたい、
        # というユーザーの提案に基づく。
        # predicted（今回のシステム予測全体、type付き）からunmatched_pred
        # （FP）をマルチセット差分すれば、残りが必ずTPになるので、追加の
        # Ollama呼び出しなしで(type, 関係語)単位のTP/FPを集計できる。
        def _rel_key(r):
            return (r.get("source"), r.get("relation"), r.get("target"), r.get("type"))

        pred_counter = Counter(_rel_key(r) for r in predicted)
        unmatched_pred_counter = Counter(_rel_key(r) for r in metrics.get("unmatched_pred", []))
        matched_counter = pred_counter - unmatched_pred_counter  # 残り＝TP

        tp_fp_by_type_relation = {}
        for key, cnt in matched_counter.items():
            tr_key = f"{key[3] or 'unknown'}|{key[1]}"
            tp_fp_by_type_relation.setdefault(tr_key, {"tp": 0, "fp": 0})
            tp_fp_by_type_relation[tr_key]["tp"] += cnt
        for key, cnt in unmatched_pred_counter.items():
            tr_key = f"{key[3] or 'unknown'}|{key[1]}"
            tp_fp_by_type_relation.setdefault(tr_key, {"tp": 0, "fp": 0})
            tp_fp_by_type_relation[tr_key]["fp"] += cnt
        if tp_fp_by_type_relation:
            keep_keys.append("tp_fp_by_type_relation")
            metrics = {**metrics, "tp_fp_by_type_relation": tp_fp_by_type_relation}

        entry = {"id": cid, **{k: v for k, v in metrics.items() if k in keep_keys}}
        if args.save_details:
            # 評価方法の検証用：全抽出結果、対応付けの詳細（方法・類似度）、
            # 厳格評価（evaluate_triples）の結果を同時に保存する。
            entry["predicted"] = predicted
            if args.eval_mode == "lenient":
                details = _lenient_match_details(
                    pp, predicted, gold, args.semantic_threshold, not args.no_semantic)
                if len(details) != metrics["正解数"]:
                    print(f"  [{cid}] 警告: 対応付けの記録（{len(details)}件）が公式の正解数"
                          f"（{metrics['正解数']}件）と一致しません")
                entry["match_details"] = details
            strict = pp.evaluate_triples(predicted, gold, lenient_relation_match=True)
            entry["strict"] = {k: strict[k] for k in ("precision", "recall", "f1", "正解数",
                                                       "システム抽出数", "正解データ数")}
        per_claim.append(entry)
        n_done_this_run += 1
        elapsed_run = time.time() - t0
        avg = elapsed_run / n_done_this_run
        remaining = n_target - n_done_this_run
        eta_min = avg * remaining / 60
        print(f"[{cid}] precision={metrics['precision']:.3f} recall={metrics['recall']:.3f} f1={metrics['f1']:.3f} "
              f"(正解{metrics['正解数']}/抽出{metrics['システム抽出数']}/正解データ{metrics['正解データ数']}) "
              f"[{n_done_this_run}/{n_target}件 経過{elapsed_run / 60:.1f}分 残り目安{eta_min:.1f}分]")
        if args.debug:
            for g in metrics["unmatched_gold"]:
                print("    見逃し:", g["source"], g["relation"], g["target"])
            for p in metrics["unmatched_pred"]:
                print("    誤抽出:", p["source"], p["relation"], p["target"])
        # 1件ごとに保存する（PCのスリープ・強制終了・ネットワーク切断等で
        # 途中終了しても、ここまでの結果は --resume で失わずに再開できる）。
        _save(out_path, per_claim, args, elapsed_run, done=False)
        _save_llm_cache(args.llm_cache, llm_cache)
        _save_llm_cache(args.verify_cache, verify_cache)

    elapsed = time.time() - t0
    _save(out_path, per_claim, args, elapsed, done=True)
    _save_llm_cache(args.llm_cache, llm_cache)
    _save_llm_cache(args.verify_cache, verify_cache)
    agg = _aggregate(per_claim)

    print("\n=== 集計 ===")
    print(f"件数: {len(per_claim)}（今回の実行で処理: {n_done_this_run}件）  "
          f"所要時間（今回の実行分）: {elapsed:.1f}秒  評価方法: {args.eval_mode}"
          + ("" if args.eval_mode in ("strict", "exact")
             else f"（主語・目的語ごとの類似度の閾値={args.node_threshold}）" if args.eval_mode == "node"
             else f"（閾値={args.semantic_threshold}, 意味的類似度={'無効' if args.no_semantic else '有効'}）"))
    print(f"MICRO precision={agg['micro']['precision']:.4f} recall={agg['micro']['recall']:.4f} f1={agg['micro']['f1']:.4f}")
    print(f"MACRO precision={agg['macro']['precision']:.4f} recall={agg['macro']['recall']:.4f} f1={agg['macro']['f1']:.4f}")

    # 【(type, 関係語)ごとのPrecision表】claim_title_ginza / ginza_has_fallback /
    # attribute（＝GiNZA由来のフォールバックで、LLMの自由な言い換えと違って
    # 語彙が限られており、「この(type, 関係語)は採用する/しない」という
    # ルールを現実的に作れる）についてだけ表示する。llm_direct/translateは
    # LLMの自由な言い換えで関係語のバリエーションが膨大になり、個別の
    # ON/OFFルールを作る対象として実用的ではないため表示対象から外す
    # （JSON側にはtype_relation_tableとして全type分を保存済み）。
    rows = _aggregate_type_relation(per_claim)
    if rows:
        print("\n=== GiNZAフォールバック系の (type, 関係語) 別 TP/FP/Precision ===")
        print("（Precisionが低いものは、その(type, 関係語)だけ不採用にする候補）")
        print(f"{'type':<20} {'relation':<20} {'TP':>5} {'FP':>5} {'Precision':>10}")
        for r in rows:
            print(f"{r['type']:<20} {r['relation']:<20} {r['tp']:>5} {r['fp']:>5} {r['precision']:>10.3f}")

    print(f"保存しました: {out_path}")


if __name__ == "__main__":
    main()
