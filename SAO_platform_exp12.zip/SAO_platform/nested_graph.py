# -*- coding: utf-8 -*-
"""SAO関係を「構成（入れ子の箱）＋関係（矢印）」の1枚の図にするDOT生成。

・備える／有する等の所有関係 → 親の箱の中に子を入れる（入れ子）
・それ以外の関係（接続される・固定される等）→ 箱と箱をつなぐ矢印
・どの部品にも属さない語（方向・設置対象など）→ 装置の箱の外に点線の楕円
・同じ部品を複数の兄弟が持つ場合（第１ヘッダと第２ヘッダがそれぞれ壁部を持つ等）
  → それぞれの箱の中に複製して描く
・上位と下位の両方が同じ部品を持つ場合（題名と具体的な部品の二重所有）
  → より具体的な方（下位）の中だけに描く
"""

import html

HAS_RELATIONS = {"有する", "備える", "具備する", "含む", "含める", "の"}
FONT = "Noto Sans CJK JP,Yu Gothic,Meiryo,sans-serif"


def _esc(s):
    return html.escape(s).replace('"', '\\"')


def relations_to_nested_dot(relations, rel_color="#2563eb"):
    rels = [r for r in relations if r["source"] != r["target"]]

    names = []
    for r in rels:
        for n in (r["source"], r["target"]):
            if n not in names:
                names.append(n)

    owners = {}
    for r in rels:
        if r["relation"] in HAS_RELATIONS:
            owners.setdefault(r["target"], [])
            if r["source"] not in owners[r["target"]]:
                owners[r["target"]].append(r["source"])

    def ancestors(n, seen=None):
        seen = set() if seen is None else seen
        out = set()
        for o in owners.get(n, []):
            if o in seen:
                continue
            seen.add(o)
            out.add(o)
            out |= ancestors(o, seen)
        return out

    # 他の所有者の祖先になっている所有者（題名などの上位）は外す
    direct_owners = {}
    for child, os_ in owners.items():
        keep = [o for o in os_
                if o != child and child not in ancestors(o)
                and not any(o in ancestors(p) for p in os_ if p != o)]
        if keep:
            direct_owners[child] = keep

    # インスタンス（描画上の箱）を作る。path = 根から自分までの名前の並び
    instances = {}  # name -> [path tuple]

    def build(name, stack=()):
        if name in stack:
            return []
        if name in instances:
            return instances[name]
        if name not in direct_owners:
            paths = [(name,)]
        else:
            paths = []
            for o in direct_owners[name]:
                for op in build(o, stack + (name,)):
                    paths.append(op + (name,))
            if not paths:
                paths = [(name,)]
        instances[name] = paths
        return paths

    for n in names:
        build(n)

    all_paths = [p for ps in instances.values() for p in ps]
    children = {}
    for p in all_paths:
        if len(p) > 1:
            children.setdefault(p[:-1], []).append(p)
    containers = set(children)
    ids = {p: f"n{i}" for i, p in enumerate(all_paths)}

    def anchor(p):
        return f"{ids[p]}_a" if p in containers else ids[p]

    lines = [
        "digraph SAO {",
        'graph [compound=true, rankdir=LR, newrank=true, nodesep=0.3, ranksep=1.1, '
        f'fontname="{FONT}", fontsize=13, bgcolor="white"];',
        f'node [fontname="{FONT}", fontsize=12, shape=box, style="rounded,filled", '
        'fillcolor="#ffffff", color="#94a3b8"];',
        f'edge [fontname="{FONT}", fontsize=11];',
    ]

    def emit(p, indent):
        pad = "  " * indent
        if p in containers:
            fill = ["#eef2ff", "#f5f7fb", "#ffffff"][min(len(p) - 1, 2)]
            lines.append(f"{pad}subgraph cluster_{ids[p]} {{")
            lines.append(f'{pad}  label="{_esc(p[-1])}"; labeljust=l; style="rounded,filled"; '
                         f'fillcolor="{fill}"; color="#64748b"; penwidth=1.3;')
            lines.append(f'{pad}  {anchor(p)} [shape=point, width=0.01, style=invis, label=""];')
            for c in children[p]:
                emit(c, indent + 1)
            lines.append(f"{pad}}}")
        elif len(p) == 1:
            lines.append(f'{pad}{ids[p]} [label="{_esc(p[-1])}", shape=ellipse, style="dashed", '
                         'color="#94a3b8", fontcolor="#475569"];')
        else:
            lines.append(f'{pad}{ids[p]} [label="{_esc(p[-1])}"];')

    for p in all_paths:
        if len(p) == 1:
            emit(p, 1)

    def closest(src_path, tgt_name):
        # 複製された相手のうち、根からの道筋を一番長く共有するものを選ぶ
        def shared(a, b):
            k = 0
            for x, y in zip(a, b):
                if x != y:
                    break
                k += 1
            return k
        return max(instances[tgt_name], key=lambda q: shared(src_path, q))

    drawn = set()
    for r in rels:
        if r["relation"] in HAS_RELATIONS:
            continue
        for sp in instances[r["source"]]:
            tp = closest(sp, r["target"])
            key = (sp, r["relation"], tp)
            if key in drawn or sp == tp:
                continue
            drawn.add(key)
            a = [f'label="{_esc(r["relation"])}"', f'color="{rel_color}"',
                 f'fontcolor="{rel_color}"', "penwidth=1.3"]
            if sp in containers:
                a.append(f"ltail=cluster_{ids[sp]}")
            if tp in containers:
                a.append(f"lhead=cluster_{ids[tp]}")
            lines.append(f"  {anchor(sp)} -> {anchor(tp)} [{', '.join(a)}];")

    lines.append("}")
    return "\n".join(lines)
